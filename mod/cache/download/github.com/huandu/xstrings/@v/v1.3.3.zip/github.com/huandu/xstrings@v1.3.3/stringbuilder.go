//+build go1.10

package xstrings

import "strings"

type stringBuilder = strings.Builder
